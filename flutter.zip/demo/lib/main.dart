import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lottie/lottie.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => EventManager(),
      child: EventApp(),
    ),
  );
}

class EventApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Event Manager',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: TextTheme(
          titleLarge: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          bodyMedium: TextStyle(color: Colors.white, fontSize: 16),
        ),
      ),
      home: LoginPage(),
    );
  }
}

class EventManager extends ChangeNotifier {
  List<Map<String, String>> events = [];

  void addEvent(Map<String, String> event) {
    events.add(event);
    notifyListeners();
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final AudioPlayer _audioPlayer =
      AudioPlayer(); // Create an AudioPlayer instance

  void _playClickSound() async {
    await _audioPlayer.play(
        AssetSource('assets/button_click.mp3')); // Play the button click sound
  }

  void _navigate(BuildContext context, String email) {
    if (email.contains('@gmail.com') ||
        email.contains('@bvrithyderabad.edu.in')) {
      if (email.contains('studentcoordinator')) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => StudentCoordinatorPage()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => UserEventsPage()),
        );
      }
    } else {
      // Show invalid email message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter a valid email')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          // Add a light background color
          color: const Color.fromARGB(255, 199, 227, 247),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Logo at the top
                  Image.asset(
                    'assets/bvrit_logo.png', // Replace with the actual logo path
                    height: 100, // Adjust height as needed
                    fit: BoxFit.contain,
                  ),
                  SizedBox(height: 20),
                  // Welcome Text
                  Text(
                    "Welcome to BVRIT HYDERABAD\nEventSphere",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                  SizedBox(height: 30),
                  // Email Text Field
                  TextField(
                    controller: emailController,
                    decoration: InputDecoration(
                      labelText: "Email",
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20),
                  // Login Button
                  ElevatedButton(
                    onPressed: () {
                      _playClickSound(); // Play the button click sound
                      _navigate(context,
                          emailController.text); // Navigate based on email
                    },
                    child: Text("Login"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      padding:
                          EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StudentCoordinatorPage extends StatefulWidget {
  @override
  _StudentCoordinatorPageState createState() => _StudentCoordinatorPageState();
}

class _StudentCoordinatorPageState extends State<StudentCoordinatorPage> {
  final TextEditingController eventNameController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController timeController = TextEditingController();
  final TextEditingController venueController = TextEditingController();
  final TextEditingController hostedByController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  // ignore: unused_field
  bool _isSubmitting = false; // To track if the form is submitting
  bool _showCelebration = false; // To control the celebration animation

  void _submitEvent() {
    if (eventNameController.text.isNotEmpty &&
        dateController.text.isNotEmpty &&
        timeController.text.isNotEmpty &&
        venueController.text.isNotEmpty &&
        hostedByController.text.isNotEmpty &&
        descriptionController.text.isNotEmpty) {
      final event = {
        'name': eventNameController.text,
        'date': dateController.text,
        'time': timeController.text,
        'venue': venueController.text,
        'hostedBy': hostedByController.text,
        'description': descriptionController.text,
      };

      // Add event to the provider
      Provider.of<EventManager>(context, listen: false).addEvent(event);

      setState(() {
        _isSubmitting = true; // Show the animation on submission
      });

      // Delay for the animation to play before navigating to the event list page
      Future.delayed(Duration(seconds: 3), () {
        setState(() {
          _showCelebration = true; // Show celebration animation
        });
        // After celebration animation, navigate to the event list
        Future.delayed(Duration(seconds: 3), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => EventListPage()),
          );
        });
      });
    }
  }

  void _logout(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null && pickedDate != DateTime.now()) {
      setState(() {
        dateController.text = "${pickedDate.toLocal()}".split(' ')[0];
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      setState(() {
        timeController.text = pickedTime.format(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Form'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: eventNameController,
                  decoration: InputDecoration(
                    labelText: 'Event Name',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: dateController,
                  decoration: InputDecoration(
                    labelText: 'Date',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  onTap: () => _selectDate(context),
                  readOnly: true,
                ),
                SizedBox(height: 10),
                TextField(
                  controller: timeController,
                  decoration: InputDecoration(
                    labelText: 'Time',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  onTap: () => _selectTime(context),
                  readOnly: true,
                ),
                SizedBox(height: 10),
                TextField(
                  controller: venueController,
                  decoration: InputDecoration(
                    labelText: 'Venue',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: hostedByController,
                  decoration: InputDecoration(
                    labelText: 'Hosted By',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(
                    labelText: 'Description',
                    labelStyle: TextStyle(color: Colors.white),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  maxLines: 3,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _submitEvent,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('Submit'),
                ),
                // Show celebration animation when event is successfully submitted
                if (_showCelebration)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Lottie.asset(
                      'assets/celebration.json', // Path to the celebration animation
                      width: 150, // Adjust the width as needed
                      height: 150, // Adjust the height as needed
                      fit: BoxFit
                          .fill, // Fit the animation inside the available space
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class UserEventsPage extends StatefulWidget {
  @override
  _UserEventsPageState createState() => _UserEventsPageState();
}

class _UserEventsPageState extends State<UserEventsPage> {
  int? selectedEventIndex; // To keep track of selected event index

  @override
  Widget build(BuildContext context) {
    final events = Provider.of<EventManager>(context).events;

    return Scaffold(
      appBar: AppBar(
        title: Text('User Events'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              // Navigate to LoginPage on logout
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: events.isEmpty
                ? Center(child: Text('No events available.'))
                : ListView.builder(
                    itemCount: events.length,
                    itemBuilder: (context, index) {
                      final event = events[index];
                      bool isSelected = selectedEventIndex == index;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            // Toggle the selection state
                            selectedEventIndex = isSelected ? null : index;
                          });
                        },
                        child: Card(
                          margin: EdgeInsets.all(10),
                          color: isSelected ? Colors.blueAccent : Colors.white,
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            title: Text(
                              event['name']!,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isSelected ? Colors.white : Colors.black,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${event['date']} at ${event['time']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Venue: ${event['venue']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Hosted by: ${event['hostedBy']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Description: ${event['description']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          // Add the Lottie animation at the bottom
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Lottie.asset(
              'assets/running_student.json', // Path to the running student animation
              width: 100, // Adjust the width as needed
              height: 100, // Adjust the height as needed
              fit: BoxFit.fill, // Fill the available space
            ),
          ),
        ],
      ),
    );
  }
}

class EventListPage extends StatefulWidget {
  @override
  _EventListPageState createState() => _EventListPageState();
}

class _EventListPageState extends State<EventListPage> {
  int? selectedEventIndex; // To keep track of selected event index

  @override
  Widget build(BuildContext context) {
    final events = Provider.of<EventManager>(context).events;

    return Scaffold(
      appBar: AppBar(title: Text('Event List')),
      body: Column(
        children: [
          Expanded(
            child: events.isEmpty
                ? Center(child: Text('No events found.'))
                : ListView.builder(
                    itemCount: events.length,
                    itemBuilder: (context, index) {
                      final event = events[index];
                      bool isSelected = selectedEventIndex == index;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            // Toggle the selection state
                            selectedEventIndex = isSelected ? null : index;
                          });
                        },
                        child: Card(
                          margin: EdgeInsets.all(10),
                          color: isSelected ? Colors.blueAccent : Colors.white,
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            title: Text(
                              event['name']!,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isSelected ? Colors.white : Colors.black,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${event['date']} at ${event['time']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Venue: ${event['venue']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Hosted by: ${event['hostedBy']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  'Description: ${event['description']}',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white70
                                        : Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          // Add the Lottie animation at the bottom
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Lottie.asset(
              'assets/running_student.json', // Path to the running student animation
              width: 100, // Adjust the width as needed
              height: 100, // Adjust the height as needed
              fit: BoxFit.fill, // Fill the available space
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to Event Form (StudentCoordinatorPage)
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => StudentCoordinatorPage()),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.blueAccent,
      ),
    );
  }
}
